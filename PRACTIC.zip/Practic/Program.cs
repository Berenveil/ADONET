﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Practic;

class Program
{
    static void Main(string[] args)
    {
        string connectionString = "Data Source = cars.db";
        CarRepository carRepository = new CarRepository(connectionString);

        var car1 = new Car { Brand = "Hyundai", Model = "Solaris", YearManufacture = new DateTime(2018, 8, 24), Price = 1850000 };
        var car2 = new Car { Brand = "Toyota", Model = "Camry", YearManufacture = new DateTime(2017, 5, 6), Price = 2200000 };
        var car3 = new Car { Brand = "Skoda", Model = "Rapid", YearManufacture = new DateTime(2015, 2, 15), Price = 1200000 };

        carRepository.Add(car1);
        carRepository.Add(car2);
        carRepository.Add(car3);

        PrintAllCars(carRepository.GetAll());

        

        static void PrintAllCars(List<Car> cars)
        {
            if (cars.Count == 0)
            {
                Console.WriteLine("Список пуст");
                return;
            }

            foreach (var car in cars)
            {
                Console.WriteLine(car.ToString());
            }
        }
    }
}