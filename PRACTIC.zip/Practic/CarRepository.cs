﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.Sqlite;

namespace Practic
{
    public class CarRepository
    {
        private readonly string _connectionString;

        public CarRepository(string connectionString)
        {
            _connectionString = connectionString;
            InitializeDatabase();
        }

        private void InitializeDatabase()
        {
            using var connection = new SqliteConnection(_connectionString);
            connection.Open();
            string query = @"
                CREATE TABLE IF NOT EXISTS Car (
                Id INTEGER PRIMARY KEY AUTOINCREMENT,
                Brand TEXT NOT NULL,
                Model TEXT NOT NULL,
                YearManufacture TEXT NOT NULL, 
                Price REAL NOT NULL
                );";
            using var command = new SqliteCommand(query, connection);
            command.ExecuteNonQuery();
        }
        public void Add(Car car)
        {
            using var connection = new SqliteConnection(_connectionString);
            connection.Open();
            string query = $@"INSERT INTO Car (Brand, Model, YearManufacture, Price)
                            VALUES (@Brand, @Model, @YearManufacture, @Price);";
            using var command = new SqliteCommand(query, connection);
            command.Parameters.AddWithValue("@Brand", car.Brand);
            command.Parameters.AddWithValue("@Model", car.Model);
            command.Parameters.AddWithValue("@YearManufacture", car.YearManufacture);
            command.Parameters.AddWithValue("@Price", car.Price);
            command.ExecuteNonQuery();
        }
        public List<Car> GetAll()
        {
            var car = new List<Car>();
            using var connection = new SqliteConnection(_connectionString);
            connection.Open();
            string query = "SELECT Id, Brand, Model, YearManufacture, Price FROM Car;";
            using var command = new SqliteCommand(query, connection);
            using var reader = command.ExecuteReader();
            while (reader.Read())
            {
                car.Add(new Car
                {
                    Id = reader.GetInt32(0),
                    Brand = reader.GetString(1),
                    Model = reader.GetString(2),
                    YearManufacture = reader.GetDateTime(3),
                    Price = reader.GetDecimal(4)
                });
            }
            return car;
        }
        public void Update(int id, decimal price = 0)
        {
            using var connection = new SqliteConnection(_connectionString);
            connection.Open();
            string query = "UPDATE Car SET Price = @Price WHERE Id = @Id";
            using var command = new SqliteCommand(query, connection);
            command.Parameters.AddWithValue("@Price",price);
            command.Parameters.AddWithValue("@Id", id);
            command.ExecuteNonQuery();
        }
        public void Delete(int id)
        {
            using var connection = new SqliteConnection(_connectionString);
            connection.Open();
            string query = "DELETE FROM Car WHERE Id = @Id;";
            using var command = new SqliteCommand(query, connection);
            command.Parameters.AddWithValue("@Id", id);
            command.ExecuteNonQuery();
        }
    }
}
