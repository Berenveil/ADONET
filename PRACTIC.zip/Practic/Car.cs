﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practic
{
    public class Car
    {
        public int Id { get; set; }
        public string Brand { get; set; }
        public string Model { get; set; }
        public DateTime YearManufacture { get; set; }
        public decimal Price { get; set; }
        public override string ToString()
        {
            return $"[{Id}] Марка и модель: {Brand} - {Model}, {YearManufacture}: Стоимость - {Price}";
        }
    }
}
