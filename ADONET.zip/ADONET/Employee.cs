﻿using System;
using System.Collections.Generic;

namespace EmployeeApp
{
    public class Employee
    {
        public int Id { get; set; }
        public required string Name { get; set; }
        public required string Position { get; set; }
        public decimal Salary { get; set; }

        public override string ToString()
        {
            return $"[{Id}] {Name} - {Position}, Зарплата: {Salary}";
        }
    }
}
